#include <bits/stdc++.h>
using namespace std;

int main(){
    //freopen("temp.in","r",stdin);
    ios::sync_with_studio(false);
    cin.tie(0);
    return 0;
}
