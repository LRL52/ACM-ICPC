//
// 1.1.cpp
// c++1x tutorial
//
// created by changkun at shiyanlou.com
//

#include "foo.h"

int main() {
    add(1, 2);
    return 0;
}
