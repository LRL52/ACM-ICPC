//
// foo.h
// c++1x tutorial
//
// created by changkun at shiyanlou.com
//


#ifdef __cplusplus
extern "C" {
#endif
    
int add(int x, int y);
    
#ifdef __cplusplus
}
#endif
