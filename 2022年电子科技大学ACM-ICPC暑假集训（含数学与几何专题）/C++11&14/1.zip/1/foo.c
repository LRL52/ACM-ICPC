//
// foo.c
// c++1x tutorial
//
// created by changkun at shiyanlou.com
//


#include "foo.h"

int add(int x, int y) {
    return x+y;
}
